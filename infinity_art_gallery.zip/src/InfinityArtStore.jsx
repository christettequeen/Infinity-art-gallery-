// Infinity Art Gallery - React Store Component
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function InfinityArtStore() {
  const [cart, setCart] = useState([]);

  const products = [
    {
      id: 1,
      name: "Floating Floral Candle Bowl",
      price: 15,
      description: "Handcrafted floating candle in a glass bowl decorated with real dried flowers.",
      image: "/images/candle_floating.jpg",
    },
    {
      id: 2,
      name: "Purple Aura Glass Candle",
      price: 15,
      description: "Elegant purple ribbed-glass candle holder with warm flame glow.",
      image: "/images/candle_purple.jpg",
    },
    {
      id: 3,
      name: "Handcrafted Nature Dome Lamp",
      price: 50,
      description: "Unique double-dome handmade lamp crafted from natural materials and vine branches.",
      image: "/images/lamp_double.jpg",
    }
  ];

  const addToCart = (item) => {
    setCart([...cart, item]);
  };

  const categories = ["Candles", "Lamps", "Handcraft Art", "Frames"];

  return (
    <div className="min-h-screen bg-purple-50 p-6">
      <header className="text-center mb-16 animate-fade-in">
        <h1 className="text-6xl font-extrabold text-purple-700 mb-3 tracking-wide drop-shadow-xl">
          Infinity ♾ Art Gallery
        </h1>
        <p className="text-purple-600 text-xl font-light italic mb-8">
          Where Creativity Meets Light & Elegance
        </p>

        <div className="mx-auto max-w-4xl bg-gradient-to-r from-purple-300/40 to-purple-100/40 p-6 rounded-3xl shadow-lg backdrop-blur-xl border border-purple-200 animate-slide-up">
          <p className="text-purple-700 text-lg">
            Discover handcrafted candles, artistic lamps & unique home décor made with passion and creativity.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-3 mt-10 animate-fade-in-slow">
          {categories.map((cat) => (
            <button
              key={cat}
              className="px-5 py-2 bg-purple-200 text-purple-700 rounded-xl hover:bg-purple-300 transition shadow-md hover:shadow-lg"
            >
              {cat}
            </button>
          ))}
        </div>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {products.map((product) => (
          <Card className="transition-transform duration-300 hover:-translate-y-2 hover:shadow-2xl bg-white/80 backdrop-blur" key={product.id}>
            <CardContent className="p-0">
              <img src={product.image} alt={product.name} className="w-full h-56 object-cover rounded-t-2xl" />
              <div className="p-4">
                <h2 className="text-xl font-semibold text-purple-700">{product.name}</h2>
                <p className="text-purple-500 mb-3">${product.price}</p>
                <Button onClick={() => addToCart(product)} className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-xl">
                  Add to Cart
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </section>

      <footer className="mt-16 p-6 text-center text-purple-600">
        <p>Your cart has {cart.length} item(s).</p>

        <Button
          className="mt-3 bg-purple-700 hover:bg-purple-800 text-white px-6 py-3 rounded-xl"
          onClick={() => alert("Redirecting to secure checkout...")}
        >
          Proceed to Checkout
        </Button>

        <div className="mt-6 text-sm text-purple-500">
          <p>Supported Payments:</p>
          <p className="mt-1">• Stripe (Visa / MasterCard)</p>
          <p>• PayPal</p>
          <p>• Mobile Money (MTN / Airtel)</p>
        </div>
      </footer>
    </div>
  );
}
