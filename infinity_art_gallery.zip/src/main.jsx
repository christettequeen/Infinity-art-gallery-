import React from "react";
import ReactDOM from "react-dom/client";
import InfinityArtStore from "./InfinityArtStore.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <InfinityArtStore />
  </React.StrictMode>
);
